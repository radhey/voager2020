import React from 'react';
import './App.css';
import CustomizedTables from './components/TableDataGrid';

function App() {
  return (
    <div className="App">
      <CustomizedTables />
    </div>
  );
}

export default App;
